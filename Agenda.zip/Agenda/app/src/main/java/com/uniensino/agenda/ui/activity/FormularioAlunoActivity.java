package com.uniensino.agenda.ui.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.uniensino.agenda.R;

public class FormularioAlunoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_aluno);
    }
}